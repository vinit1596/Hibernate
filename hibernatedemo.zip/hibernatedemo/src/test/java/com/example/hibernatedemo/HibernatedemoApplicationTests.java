package com.example.hibernatedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernatedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
