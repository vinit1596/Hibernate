package com.hibdemo.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.hibdemo.bean.EMPHIBER;
import com.hibdemo.util.HibernateUtil;

@Repository
public class EmpDAOImpl implements EmpDAO {

	@Override
	public void registerEmployee(EMPHIBER emphiber) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();		
		session.save(emphiber);		
		session.getTransaction().commit();
		
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public List<EMPHIBER> getAllEmp() {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();	
		List<EMPHIBER> list =  session.createCriteria(EMPHIBER.class).list();
		System.out.println("Records fetched:"+list.size());
		session.getTransaction().commit();
		return list;
	}

	@SuppressWarnings({ "deprecation", "rawtypes" })
	@Override
	public void deleteEmp(String ssn) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();	
		Query query = session.createSQLQuery("delete from EMPHIBER  where ssn =:ssn");
		query.setString("ssn", ssn);
		query.executeUpdate();
		session.getTransaction().commit();
		
	}

	@SuppressWarnings("deprecation")
	@Override
	public EMPHIBER getEmpBySsn(String ssn) {
		// TODO Auto-generated method stub
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();	
		Criteria criteria = session.createCriteria(EMPHIBER.class);
        criteria.add(Restrictions.eq("ssn", ssn));
		session.getTransaction().commit();
		return (EMPHIBER)criteria.uniqueResult();
	}

	@Override
	public void updateEmployee(EMPHIBER emphiber) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();		
		session.merge(emphiber);		
		session.getTransaction().commit();
	}

	
	
}
