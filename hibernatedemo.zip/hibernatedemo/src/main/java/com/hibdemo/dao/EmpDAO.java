package com.hibdemo.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.hibdemo.bean.EMPHIBER;

@Component
public interface EmpDAO {

	public void registerEmployee(EMPHIBER emphiber);	
	public List<EMPHIBER> getAllEmp();
	public void deleteEmp(String ssn);
	public EMPHIBER getEmpBySsn(String ssn);
	public void updateEmployee(EMPHIBER emphiber);
	
}
