package com.hibdemo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="EMPHIBER")
public class EMPHIBER {

	/*
	 * Directly can't use sequence generator, need to use via @Genericgenerator
	 * as sequencegenerator uses default allocation type which is different than spring, so overrided here
	 * Not supported auto_increment in oracle 11g
	 * 
	 */	
	@Id
	@Column(name = "ID", updatable = false, nullable = false)
	@GenericGenerator(name = "id_seq", strategy = "sequence", parameters = {
            @org.hibernate.annotations.Parameter(name = "sequenceName", value = "id_seq"),
            @org.hibernate.annotations.Parameter(name = "allocationSize", value = "1"),
    })
    @GeneratedValue(generator = "id_seq", strategy=GenerationType.SEQUENCE)
	private int id;
	
	@NotNull
	@Column(name = "NAME", nullable = false)
	private String name;
	
	@NotNull
    @Digits(integer=8, fraction=2)
    @Column(name = "SALARY", nullable = false)
	private double salary;
	
	@NotNull
	@Column(name = "SSN", nullable = false, unique=true)
	private String ssn;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	@Override
	public String toString() {
		return "EMPHIBER: [id=" + id + ", name=" + name + ", salary=" + salary + ", ssn=" + ssn + "]";
	}
	
	
	
}
