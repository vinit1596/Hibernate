package com.hibdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibdemo.bean.EMPHIBER;
import com.hibdemo.dao.EmpDAO;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	EmpDAO empdao;
	
	@Override
	public void registerEmployee(EMPHIBER emphiber) {
		empdao.registerEmployee(emphiber);		
	}

	@Override
	public List<EMPHIBER> getAllEmp() {
		return empdao.getAllEmp();
	}

	@Override
	public void deleteEmp(String ssn) {
		empdao.deleteEmp(ssn);
	}

	@Override
	public boolean getEmpBySsn(String ssn) {
		if(empdao.getEmpBySsn(ssn) != null) {
			System.out.println("Exists!.....");
			return true;
		}
		System.out.println("Not Exists!.....");
		return false;
	}

	@Override
	public EMPHIBER getEmpBySSN(String ssn) {
		return empdao.getEmpBySsn(ssn);
	}

	@Override
	public void updateEmployee(EMPHIBER emphiber) {
		empdao.updateEmployee(emphiber);
	}

}
