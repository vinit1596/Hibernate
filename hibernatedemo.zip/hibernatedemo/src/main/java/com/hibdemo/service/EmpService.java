package com.hibdemo.service;

import java.util.List;

import com.hibdemo.bean.EMPHIBER;

public interface EmpService {

	public void registerEmployee(EMPHIBER emphiber);
	public List<EMPHIBER>getAllEmp();
	public void deleteEmp(String ssn);
	public boolean getEmpBySsn(String ssn);
	public EMPHIBER getEmpBySSN(String ssn);
	public void updateEmployee(EMPHIBER emphiber);
	
}
