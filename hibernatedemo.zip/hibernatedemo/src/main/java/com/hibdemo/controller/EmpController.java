package com.hibdemo.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hibdemo.bean.EMPHIBER;
import com.hibdemo.dao.EmpDAO;
import com.hibdemo.service.EmpService;

@Controller
@RequestMapping("/")
public class EmpController {

	@Autowired
	EmpService empservice;
	
	@Autowired
    MessageSource messageSource;
	
	@RequestMapping(value = { "/", "/list"}, method = RequestMethod.GET)
	public String listEmployees(ModelMap model) {
		List<EMPHIBER> employees = empservice.getAllEmp();
		model.addAttribute("employees", employees);
		return "list";
	}
	
	/*
	 * 
	 * ModelMap attribute created is referred in jsp page called and used using jstl tag support(form)
	 * modelAttribute is used to refer it
	 * then can use same parameters as referred in modelAttribute using form jstl tag
	 * 
	 */
	@RequestMapping(value = { "/new"}, method = RequestMethod.GET)
	public String addNewEmployees(ModelMap model) {
		EMPHIBER emphiber = new EMPHIBER();
        model.addAttribute("emphiber", emphiber);
        model.addAttribute("edit", false);
		return "registration";
	}
	
	@RequestMapping(value = { "/new"}, method = RequestMethod.POST)
	public String registerEmployees(@Valid EMPHIBER emphiber,BindingResult result, ModelMap model) {
		if (result.hasErrors()) {
            return "registration";
        }
		
		if(empservice.getEmpBySsn(emphiber.getSsn()))
		{
	        model.addAttribute("emphiber", emphiber);
			model.addAttribute("exists", "Employee with SSN " + emphiber.getSsn() + " already exists!...");
			return "registration";
		}
		
		empservice.registerEmployee(emphiber);
		model.addAttribute("success", "Employee " + emphiber.getName() + " registered successfully");
		return "success";
	}
	
	@RequestMapping(value = { "/delete-{ssn}-employee" }, method = RequestMethod.GET)
    public String deleteEmployee(@PathVariable String ssn) {
		empservice.deleteEmp(ssn);
		return "redirect:/list";
	}
	
	@RequestMapping(value = { "/edit-{ssn}-employee" }, method = RequestMethod.GET)
    public String editEmployee(@PathVariable String ssn, ModelMap model) {
		
		EMPHIBER emphiber = empservice.getEmpBySSN(ssn);
		model.addAttribute("emphiber", emphiber);
		model.addAttribute("edit", true);
		return "registration";
	}
	
	@RequestMapping(value = { "/edit-{ssn}-employee" }, method = RequestMethod.POST)
    public String updateEmployee(@PathVariable String ssn, ModelMap model, @Valid EMPHIBER emphiber,BindingResult result) {
		
		if(empservice.getEmpBySsn(emphiber.getSsn()))
		{
	        model.addAttribute("emphiber", emphiber);
			model.addAttribute("exists", "Employee with SSN " + emphiber.getSsn() + " already exists!...");
			return "registration";
		}
		
		empservice.updateEmployee(emphiber);
		model.addAttribute("success", "Employee " + emphiber.getName() + " updated successfully");
		return "success";
	}
	
}
